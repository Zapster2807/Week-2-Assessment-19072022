object Ans1
{
	//Main method
	def main(args: Array[String])
	{	
		val strToFormat = "http://www.google.com"
		val reversedAndToUpperCase = strToFormat.reverse.toUpperCase()
		println(s"$reversedAndToUpperCase")
	}
}